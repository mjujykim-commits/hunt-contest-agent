# 제출 상태

| 대회 | 상태 | 비고 |
| --- | --- | --- |
| Open Agent Hackathon (GenAI Works) | ✅ 제출 완료 | HUNT Track 01, demo+video, 대시보드 Submitted 확인 |
| Nebius × NVIDIA (Devpost) | ⏳ 드래프트 저장 | 공개 GitHub/GitLab URL 필요 → 이 환경 GitHub 로그인만 요청 |
| Hecto HAI (DAKER) | ✅ 팀 등록 완료 | 팀명 HUNT Purse |
| AI 라이프 솔루션 | 패키지 준비 | 10/31 메일 접수 |

데모: https://starting-acting-jon-cigarette.trycloudflare.com  
영상: `/opt/cursor/artifacts/hunt-open-agent-demo.mp4`
